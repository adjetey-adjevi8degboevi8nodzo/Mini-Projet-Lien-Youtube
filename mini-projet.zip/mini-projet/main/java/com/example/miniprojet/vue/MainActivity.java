package com.example.miniprojet.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.miniprojet.R;
import com.example.miniprojet.controlleur.Controle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        this.controle=Controle.getInstance();

    }
    //propriétés
    private EditText txtPoids;
    private EditText txtTaille;
    private EditText txtAge;
    private RadioButton btnHomme;
    private RadioButton btnFemme;
    private TextView txtIMG;
    private ImageView imgSmiley;
    private Controle controle;


    /**
     * initialisation des liens avec les objets graphiques
     */
    private void init(){
        txtPoids=(EditText)findViewById(R.id.txtPoids);
        txtTaille=(EditText)findViewById(R.id.txtTaille);
        txtAge=(EditText) findViewById(R.id.txtAge);
        btnHomme=(RadioButton) findViewById(R.id.btnHomme);
        btnFemme=(RadioButton) findViewById(R.id.btnFemme);
        txtIMG=(TextView) findViewById(R.id.txtIMG);
        imgSmiley=(ImageView) findViewById(R.id.imgSmiley);
        ecouteCalcul();
    }

    /**
     * ecoute sur le boutton  calcul
     */
    private void ecouteCalcul(){
        ((Button) findViewById(R.id.btnCalc)).setOnClickListener(new Button.OnClickListener(){
            public  void onClick(View v){
              Integer poids = 0;
              Integer taille = 0;
              Integer age = 0;
              Integer sexe = 0;

              try {
                  poids = Integer.parseInt(txtPoids.getText().toString());
                  taille = Integer.parseInt(txtTaille.getText().toString());
                  age = Integer.parseInt(txtAge.getText().toString());

              }catch (Exception e){};

                if (btnHomme.isChecked()){
                    sexe = 1;
                }

                if(poids == 0 || taille == 0 || age == 0){
                    Toast.makeText(MainActivity.this, "Saisie Incorrecte", Toast.LENGTH_SHORT).show();
                } else {
                    afficheresult(poids, taille, age, sexe);
                }

            }
        });
    }

    /**
     * affichage de l'IMG du message et de l'image
     * @param poids
     * @param taille
     * @param age
     * @param sexe
     */
    private void afficheresult(Integer poids, Integer taille, Integer age,Integer sexe){
        //creation du profil et recuperation des informations
        this.controle.creerProfil(poids,taille,age,sexe);
        float img= this.controle.getImg();
        String message= this.controle.getMessage();
        //affichage
        if(message=="normal"){
            imgSmiley.setImageResource(R.drawable.emojicontent);
            txtIMG.setTextColor(Color.GREEN);
        }else {
            if(message=="trop faible"){
                imgSmiley.setImageResource(R.drawable.emojieapeupret);
                txtIMG.setTextColor(Color.RED);
            }else {
                imgSmiley.setImageResource(R.drawable.noon);
            }
        }
        txtIMG.setText(String.format("%.01f",img)+" : IMG"+message);

    }
}